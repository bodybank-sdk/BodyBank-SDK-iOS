# BodyBank Enterprise SDK Readme

## Version
2018-11-08-2

## Install
Use cocoapods.

```
pod 'BodyBankEnterprise'
```

When install, do
```
pod install
```

When update, do
```
pod update BodyBankEnterprise && pod install
```

## Usage


### Set up
Include the `bodybank-config.json` file into main bundle by dragging the file into project navigator on Xcode.
The file is provided after making a contract.

### Mobile SDK

#### Token Provider development
Implement the `BodyBankTokenProvider` protocol and return `token` and `identity_id` wrapped in a `BodyBankToken` from overriden getters.
```swift
class TokenProvider: BodyBankTokenProvider{
    var token: BodyBankToken{
        get{
            return BodyBankToken(
                jwtToken: "<token>",
                identityId: "<identity_id>")
        }
    }
}

```
`token` and `identity_id` should be fetched using Admin API (documented separately)

Everytime identityId changes, do
```swift
BodyBankEnterprise.clearCredentials()
```

#### SDK initialization

Initialize BodyBank in `AppDelegate.swift`

```swift
import BodyBankEnterprise

func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool{
    BodyBankEnterprise.initialize(tokenProvider: TokenProvider())
    return true
}
```

#### Modifying JWT Token after initialization
The active Token Provider can be fetched by
```swift
BodyBankEnterprise.tokenProvider()

```
Please modify jwt using this reference.

#### Create New BodyBank Estimation Request
```swift
var params = EstimationParameter()
params.frontImage = Estimation.shared.frontImage
params.sideImage = Estimation.shared.sideImage
params.heightInCm = Estimation.shared.heightInCm
params.weightInKg = Estimation.shared.weight!
params.age = 30
params.gender = .male
BodyBankEnterprise.createEstimationRequest(estimationParameter: params, callback: { (request, error) in
    if error == nil{
        print(request?.id)
    }else{
        print(error)
    }
})
```
#### Get BodyBank Estimation Requests
```swift
// List estimation requests
BodyBankEnterprise.listEstimationRequests(limit: 20, nextToken: nil, callback: { (requests, nextToken, error) in
    print(requests)
})

// Get estimation request and result detail
BodyBankEnterprise.getEstimationRequest(id: id, callback: { (request, error) in
    print(request)
})

```

#### Subscribe & Unsubscribe Changes

```swift
BodyBankEnterprise.subscribeUpdateOfEstimationRequests(callback: { (request, errors) in
    print(errors)
})


BodyBankEnterprise.unsubscribeEstimationRequests()

```

#### Get images
```swift
let url = request.frontImage?.downloadableURL
//Do anything with pre-signed downloadable URL
//It has expiration time.

```



