# BodyBank Enterprise SDK Readme

## Install
Use cocoapods.

```
pod 'BodyBankEnterprise'
```

## Usage

### Initialization
Include the `bodybank-config.json` file into main bundle. The file is provided after making a contract.
Implement server API to request BodyBank Enterprise endpoint for user token. Usages are like:
```
curl -H 'Content-Type:application/json' -X POST  -H 'Content-Type:application/json' -H 'x-api-key:MeqhdihRpaSr1hNM5Buk6cYHWUCb7cO3vkCXEx19' -d  '{"user_id":"skonb@me.com"}' https://api.<YOUR SERVIE IDENTIFIER>.enterprise.bodybank.com/token

```
`YOUR SERVIE IDENTIFIER` above is provided after making a contract.

Implement the `BodyBankTokenProvider` protocol and return `token` and `identity_id` from overriden getters.
```
class TokenProvider: BodyBankTokenProvider{
    var token: String{
        get{
            return "token"
        }
    }

    var identityId: String{
        get{
            return "identityId"
        }
    }
}

```


Initialize BodyBank in `AppDelegate.swift`

```
import BodyBankEnterprise

func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool{
    BodyBankEnterprise.initialize(tokenProvider: TokenProvider())
    return true
}
```

### Create New BodyBank Estimation Request
```
var params = EstimationParameter()
params.frontImage = Estimation.shared.frontImage
params.sideImage = Estimation.shared.sideImage
params.heightInCm = Estimation.shared.heightInCm
params.weightInKg = Estimation.shared.weight!
params.age = 30
params.gender = .male
BodyBankEnterprise.createEstimationRequest(estimationParameter: params, callback: { (request, error) in
    if error == nil{
        print(request?.id)
    }else{
        print(error)
    }
})
```
### Get BodyBank Estimation Requests
```
// List estimation requests
BodyBankEnterprise.listEstimationRequests(limit: 20, nextToken: nil, callback: { (requests, nextToken, error) in
    print(requests)
})

// Get estimation request and result detail
BodyBankEnterprise.getEstimationRequest(id: id, callback: { (request, error) in
    print(request)
})

```

