# BodyBank SDK Readme

## Registration

TBD

You can get API Key & Secret when requested.

## Install
Use cocoapods.

```
pod 'BodyBank'
```


## Usage

### Initialization
In `AppDelegate.swift` in

```
func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool{```
    BodyBank.initialize(clientId: "<Client ID>")
...
```
```
func application(_ app: UIApplication, open url: URL, options: [UIApplicationOpenURLOptionsKey : Any] = [:]) -> Bool {
    return BodyBank.application(app, open:url, options: options)
}
```

### BodyBank User Registration/Sign in
```
BodyBank.signIn(fromViewController: self) { (error) in

}
```

### Create New BodyBank Estimation Request
```
var params = EstimationParameter()
params.frontImage = Estimation.shared.frontImage
params.sideImage = Estimation.shared.sideImage
params.heightInCm = Estimation.shared.heightInCm
params.weightInKg = Estimation.shared.weight!
params.age = 30
params.gender = .male
BodyBank.createEstimationRequest(estimationParameter: params, callback: { (request, error) in
    if error == nil{
        print(request?.id)
    }else{
        print(error)
    }
})
```
### Get BodyBank Estimation Requests
```
// List estimation requests
BodyBank.listEstimationRequests(limit: 20, nextToken: nil, callback: { (requests, nextToken, error) in
    print(requests)
})

// Get estimation request and result detail
BodyBank.getEstimationRequest(id: id, callback: { (request, error) in
    print(request)
})

```

--- Below are under development ---

```
pod 'BodyBankUI'
```


### Preconfigured Camera UI
```
var vc = BobyBankCameraViewController()
vc.delegate = self
present(viewController: vc)
```
delegate methods are

```
func bodybankCameraViewController(viewController: BobyBankCameraViewController, didCapturePhoto photo: UIImage)
func bodybankCameraViewController(viewController: BobyBankCameraViewController, didUpdateBodyParameters bodyParameters: [String: Any])
func bodybankCameraViewControllderDidCancel(viewController: BobyBankCameraViewController)
func bodybankCameraViewControllderDidFinish(viewController: BobyBankCameraViewController)
etc...
```
### Preconfigured Estimation Request List UI
```
var vc = BodyBankEstimationRequestListViewController()
present(viewController: vc)
```

### Preconfigured Estimation Request Detail UI
```
var vc = BodyBankEstimationRequestDetailViewController()
vc.estimationRequest = request
present(viewController: vc)
```
