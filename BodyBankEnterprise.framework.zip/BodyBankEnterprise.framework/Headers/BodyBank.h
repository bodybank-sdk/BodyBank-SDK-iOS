//
//  BodyBank.h
//  BodyBank
//
//  Created by Shunpei Kobayashi on 2018/07/17.
//  Copyright © 2018, Shunpei Kobayashi. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for BodyBank.
FOUNDATION_EXPORT double BodyBankVersionNumber;

//! Project version string for BodyBank.
FOUNDATION_EXPORT const unsigned char BodyBankVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BodyBank/PublicHeader.h>


